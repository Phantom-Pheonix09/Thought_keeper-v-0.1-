import { HttpError } from 'wasp/server'

export const createEntry = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };
  return context.entities.Entry.create({
    data: {
      title: args.title,
      content: args.content,
      userId: context.user.id
    }
  });
}

export const updateEntry = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  const entry = await context.entities.Entry.findUnique({
    where: { id: args.id }
  });
  if (entry.userId !== context.user.id) { throw new HttpError(403) };

  return context.entities.Entry.update({
    where: { id: args.id },
    data: { title: args.title, content: args.content }
  });
}

export const deleteEntry = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };
  const entry = await context.entities.Entry.findUnique({
    where: { id: args.entryId }
  });
  if (entry.userId !== context.user.id) { throw new HttpError(403) };
  return context.entities.Entry.delete({
    where: { id: args.entryId }
  });
}