import React, { useState } from 'react';
import { useAction, createEntry } from 'wasp/client/operations';
import { Link } from 'react-router-dom';

const NewEntry = () => {
  const createEntryFn = useAction(createEntry);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');

  const handleCreateEntry = () => {
    createEntryFn({ title, content });
    setTitle('');
    setContent('');
  };

  return (
    <div className='p-4'>
      <input
        type='text'
        placeholder='Title'
        className='px-1 py-2 border rounded text-lg'
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />
      <textarea
        placeholder='Content'
        className='px-1 py-2 border rounded text-lg mt-2'
        value={content}
        onChange={(e) => setContent(e.target.value)}
      ></textarea>
      <button
        onClick={handleCreateEntry}
        className='bg-blue-500 hover:bg-blue-700 px-2 py-2 text-white font-bold rounded mt-2'
      >
        Create Entry
      </button>
      <Link to='/' className='bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded ml-2'>
        Go to Home
      </Link>
    </div>
  );
}

export default NewEntry;