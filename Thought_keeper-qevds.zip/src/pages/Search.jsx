import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery, searchEntries } from 'wasp/client/operations';

const SearchPage = () => {
  const [keyword, setKeyword] = useState('');
  const { data: entries, isLoading, error } = useQuery(searchEntries, { keyword });

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  return (
    <div className='p-4'>
      <input
        type='text'
        placeholder='Search keyword'
        className='px-1 py-2 border rounded text-lg'
        value={keyword}
        onChange={(e) => setKeyword(e.target.value)}
      />
      {entries.map((entry) => (
        <div key={entry.id} className='bg-gray-100 p-4 mb-4 rounded-lg'>
          <div>Title: {entry.title}</div>
          <div>Content: {entry.content}</div>
          <div>Created At: {entry.createdAt}</div>
          <div>Updated At: {entry.updatedAt}</div>
        </div>
      ))}
    </div>
  );
}

export default SearchPage;