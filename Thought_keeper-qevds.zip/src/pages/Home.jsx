import React, { useState } from 'react';
import { useQuery, useAction, getEntries, deleteEntry } from 'wasp/client/operations';
import { Link } from 'react-router-dom';

const HomePage = () => {
  const { data: entries, isLoading, error } = useQuery(getEntries);
  const deleteEntryFn = useAction(deleteEntry);

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleDeleteEntry = (entryId) => {
    deleteEntryFn({ entryId });
  };

  return (
    <div className='p-4'>
      {entries.map((entry) => (
        <div key={entry.id} className='bg-gray-100 p-4 mb-4 rounded-lg'>
          <div className='flex items-center justify-between'>
            <div>{entry.title}</div>
            <div>{new Date(entry.createdAt).toDateString()}</div>
            <button
              onClick={() => handleDeleteEntry(entry.id)}
              className='bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded'
            >
              Delete
            </button>
          </div>
          <div>{entry.content}</div>
          <Link to={`/entry/${entry.id}`} className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mt-2'>Details</Link>
        </div>
      ))}
    </div>
  );
}

export default HomePage;