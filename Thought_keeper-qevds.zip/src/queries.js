import { HttpError } from 'wasp/server'

export const getEntries = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };

  return context.entities.Entry.findMany({
    where: {
      userId: context.user.id
    }
  });
}

export const getEntry = async ({ id }, context) => {
  if (!context.user) { throw new HttpError(401) };

  const entry = await context.entities.Entry.findUnique({
    where: { id, userId: context.user.id },
    select: {
      id: true,
      title: true,
      content: true,
      createdAt: true,
      updatedAt: true
    }
  });

  if (!entry) throw new HttpError(404, 'No entry with id ' + id);

  return entry;
}

export const searchEntries = async (args, context) => {
  if (!context.user) { throw new HttpError(401) };
  return context.entities.Entry.findMany({
    where: {
      title: { contains: args.keyword },
      userId: context.user.id
    }
  });
}